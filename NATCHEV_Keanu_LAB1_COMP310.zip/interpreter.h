int help(char *words[]);
int quit(char *words[]);
int set(char *words[]);
int print(char *words[]);
int run(char *words[]);
int interpreter(char *words[]);