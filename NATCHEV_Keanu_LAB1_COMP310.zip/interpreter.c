#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "interpreter.h"
#include "shellmemory.h"
#include "shell.h"

int help(char *words[])
{
    // Checking if the print format is respected.
    if (strcmp(words[1], "") == 0)
    {
        printf("\n");
        printf("Supported Commands:\n");
        printf("____________________________________________________________\n");
        printf("|     COMMAND      |               DESCRIPTION             |\n");
        printf("____________________________________________________________\n");
        printf("| help             | Displays all the commands             |\n");
        printf("| quit             | Exits/terminates the shell with \"Bye!\"|\n");
        printf("| set VAR STRING   | Assigns a value to shell memory       |\n");
        printf("| print VAR        | Displays the STRING assigned to VAR   |\n");
        printf("| run SCRIPT.TXT   | Executes the file SCRIPT.TXT          |\n");
        printf("____________________________________________________________\n");
        printf("\n");
        return 0;
    }
    printf("Unknown command\n");
    return 1;
}

int quit(char *words[])
{
    // Checking if the quit format is respected.
    if (strcmp(words[1], "") == 0)
    {
        printf("Bye!\n");
        return -1;
    }
    printf("Unknown command\n");
    return 0;
}

int set(char *words[])
{
    // Calling shellmemory setMEM.
    return setMEM(words);
}

int print(char *words[])
{
    // Calling shellmemory printMEM.
    return printMEM(words);
}

int run(char *words[])
{
    // Checking if the run SCRIPT.TXT format is respected.
    if ((strcmp(words[2], "") == 0) && (strcmp(words[1], "") != 0))
    {
        int errorCode = 0;
        char line[1000];
        FILE *p;

        // Opening the file.
        if (p = fopen(words[1], "r"))
        {
            while (fgets(line, 999, p))
            {
                size_t ln = strlen(line) - 1;
                if (line[ln] == '\n')
                    line[ln] = '\0';
                errorCode = parser(line);
            }
            fclose(p);
        }
        // If the file cannot be found and opened.
        else
        {
            printf("Script not found\n");
            return errorCode;
        }

        return errorCode;
    }
    printf("Unknown command\n");
    return 0;
}

int interpreter(char *words[])
{
    int errorCode = 0;
    // Checking for all supported commands.
    if (strcmp(words[0], "help") == 0)
        errorCode = help(words);
    else if (strcmp(words[0], "quit") == 0)
        errorCode = quit(words);
    else if (strcmp(words[0], "set") == 0)
        errorCode = set(words);
    else if (strcmp(words[0], "print") == 0)
        errorCode = print(words);
    else if (strcmp(words[0], "run") == 0)
        errorCode = run(words);
    else
    {
        printf("Unknown command\n");
    }
    return errorCode;
}