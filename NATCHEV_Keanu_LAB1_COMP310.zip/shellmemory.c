#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "shellmemory.h"
#include "interpreter.h"
#include "shell.h"

// Shell memory for VAR/STRING storage.
struct SHELLMEMORY
{
    char *variable;
    char *value;
};
struct SHELLMEMORY variables[1000];

int setMEM(char *words[])
{
    // Checking if the set VAR STRING format is respected.
    if ((strcmp(words[3], "") == 0) && (strcmp(words[2], "") != 0))
    {
        // Simultaneously checking for the existence of the VAR and creating a new VAR in the
        //  case we reach a NULL entry in the array.
        for (int i = 0; i < 1000; i++)
        {
            if (i == 999){
                printf("Exceeding maximum memory size.");
                break;
            }
            else if (!variables[i].variable)
            {
                variables[i].variable = words[1];
                variables[i].value = words[2];
                printf("Successfully added VAR: %s with STRING: %s.\n", words[1], words[2]);
                break;
            }
            else if (strcmp(variables[i].variable, words[1]) == 0)
            {
                variables[i].value = words[2];
                printf("Successfully updated VAR: %s with STRING: %s.\n", words[1], words[2]);
                break;
            }
        }
        return 0;
    }
    printf("Unknown command\n");
    return 0;
}

int printMEM(char *words[])
{
    // Checking if the print VAR format is respected.
    if ((strcmp(words[2], "") == 0) && (strcmp(words[1], "") != 0))
    {
        // Going through existing entries in the array.
        for (int i = 0; i < 1000; i++)
        {
            // If we reach a NULL entry in the array, we stop looking.
            if (!variables[i].variable)
            {
                printf("VAR NOT FOUND!\n");
                break;
            }
            // If we find the VAR, we print the message below and stop looking.
            if (strcmp(variables[i].variable, words[1]) == 0)
            {
                printf("The string associated with VAR: %s is STRING: %s\n", words[1], variables[i].value);
                break;
            }
        }
        return 0;
    }
    printf("Unknown command\n");
    return 0;
}