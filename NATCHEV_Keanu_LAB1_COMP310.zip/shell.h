int parser(char ui[]);
int main(int argc, char *argv[]);