#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "shell.h"
#include "interpreter.h"
#include "shellmemory.h"

int parser(char ui[])
{
        char tmp[200];
        char *words[100];
        // Making sure that the words array is empty ("").
        for (int i = 0; i < 100; i++)
                words[i] = "";

        int i, j;
        int idx = 0;

        // Skipping all white spaces at the beginning of the command.
        for (i = 0; ui[i] == ' ' && i < 1000; i++);

        // Building the array of arguments.
        while (ui[i] != '\0' && i < 1000)
        {
                for (j = 0; ui[i] != '\0' && ui[i] != ' ' && i < 1000; i++, j++)
                        tmp[j] = ui[i];
                tmp[j] = '\0';
                words[idx] = strdup(tmp);
                i++;
                idx++;
        }
        // Calling the interpreter on the array of arguments.
        return interpreter(words);
}

int main(int argc, char *argv[])
{
        char prompt[100] = {'$', '\0'};
        char userInput[1000];
        int errorCode = 0;

        printf("Welcome to the Keanu Natchev shell!\n");
        printf("Version 1.0 Created January 2020\n");

        while (1)
        {
                printf("%s", prompt);
                fgets(userInput, 999, stdin);

                // Removing the \n at the end of input.
                size_t ln = strlen(userInput) - 1;
                if (userInput[ln] == '\n')
                        userInput[ln] = '\0';

                // Calling the parser on the command.
                errorCode = parser(userInput);

                if (errorCode == -1)
                        exit(99);
        }
}