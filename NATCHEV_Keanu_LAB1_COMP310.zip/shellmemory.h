int setMEM(char *words[]);
int printMEM(char *words[]);